
<section class="content">
	<div class="row">
    <div class="col-xs-12">
      <div class="box">
		
        <div class="box-body box-table">
		Selamat Datang <b><?php echo $this->session->userdata('nama_user'); ?></b>, di Sistem Informasi Stok Barang Rumah Sakit Royal Surabaya.
		</div>
	</div>
	</div>
	</div>    
</section>
  
